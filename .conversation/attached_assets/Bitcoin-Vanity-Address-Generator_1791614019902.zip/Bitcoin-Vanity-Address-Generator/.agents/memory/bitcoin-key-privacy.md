---
name: Bitcoin key privacy
description: Security boundaries for the Bitcoin Vanity Generator.
---

All private-key generation, address derivation, and vanity searching must stay on the user's device. Never send or persist generated private keys, WIF values, or address history. Persist range bounds, address format, and batch size only when the user explicitly requests same-tab auto-resume, and then only in sessionStorage.

**Why:** A private key grants full control of funds, while scanning a user-selected numeric range creates predictable keys that can be guessed. The user explicitly chose to save only the range bounds in this browser tab so a refresh can restart the scan.

**How to apply:** Keep cryptographic work in the browser worker. Treat custom low-to-high range scanning as educational only, require an explicit acknowledgement, and prominently advise users never to hold funds at an address derived from a predictable range. For same-tab auto-resume, store only low/high bounds, address format, and batch size in sessionStorage; keep generated addresses and WIFs in memory and rebuild them from the saved low bound after refresh. After a completed block, the next block starts at the previous high plus one and uses the same count.
